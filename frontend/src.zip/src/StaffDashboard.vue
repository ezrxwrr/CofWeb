<template>
  <div class="mobile-container">
    <div class="scroll-content">
      <nav class="top-nav">
        <button class="icon-btn anim-subtle">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
        </button>
        <div class="logo"><span class="logo-text">Ijoo Staff</span></div>
      </nav>

      <transition name="tab-fade" mode="out-in">
        <div class="content" v-if="activeTab === 'dashboard'" key="dashboard">
          <h1 class="title">Ringkasan Hari Ini</h1>
          <p class="date-display">{{ todayDate }}</p>
          <div class="stats-grid">
            <div class="stat-card"><div class="stat-top"><span class="stat-number">2</span></div><p class="stat-label">TOTAL RESERVASI</p></div>
            <div class="stat-card"><div class="stat-top"><span class="stat-number">1</span></div><p class="stat-label">MENUNGGU</p></div>
          </div>
          <div class="section-header"><h2>Status Meja Live</h2></div>
          <div class="table-status-scroll">
            <div class="table-card card-occ"><p class="table-name">T-02</p><span class="status-dropdown">Occupied</span></div>
          </div>
        </div>

        <div class="content" v-else-if="activeTab === 'reservations'" key="reservations">
          <h1 class="title">Daftar Reservasi</h1>
          <div class="reservation-list" style="margin-top: 24px;">
            <div class="res-card">
              <div class="res-info">
                <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                  <h3>Andreana</h3><span class="badge badge-pending">PENDING</span>
                </div>
                <p>⏱ 14:00 | 👥 2 Pax | 🪑 Meja T-02</p>
              </div>
            </div>
          </div>
        </div>

        <div class="content" v-else-if="activeTab === 'menu'" key="menu">
          <h1 class="title">Manajemen Menu</h1>
          <p class="date-display">Atur ketersediaan dan harga real-time.</p>
          <div class="menu-admin-list">
            <div class="menu-admin-card" v-for="item in menuItems" :key="item.id">
              <div class="menu-admin-image-section">
                <div class="menu-image-preview" v-if="item.imagePreview">
                  <img :src="item.imagePreview" :alt="item.name" class="menu-image">
                </div>
                <div class="menu-image-placeholder" v-else>
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#A4B298" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                </div>
                <label class="upload-label">
                  <input 
                    type="file" 
                    class="file-input" 
                    accept="image/png,image/jpeg,image/webp,.png,.jpg,.jpeg,.webp"
                    @change="handleImageUpload($event, item.id)"
                  />
                  <span class="upload-btn">{{ item.imageFile ? '✓ Terpilih' : 'Unggah Gambar' }}</span>
                </label>
              </div>
              <div class="menu-admin-info">
                <h4>{{ item.name }}</h4>
                <p class="price-display">{{ item.price }}</p>
              </div>
            </div>
          </div>
          
          <div class="upload-status" v-if="uploadMessage">
            <p :class="uploadSuccess ? 'success-msg' : 'error-msg'">{{ uploadMessage }}</p>
          </div>
        </div>
      </transition>
    </div>

<<<<<<< Updated upstream
    <div class="modal-overlay" v-if="showMenuForm" @click="showMenuForm = false">
      <div class="modal-content" @click.stop>
        <h3>Tambah Menu Baru</h3>
        <div class="form-group">
          <label>NAMA MENU</label>
          <input type="text" v-model="newMenu.nama_item" placeholder="Nama menu" class="form-input" />
        </div>
        <div class="form-group">
          <label>DESKRIPSI</label>
          <input type="text" v-model="newMenu.deskripsi" placeholder="Deskripsi menu" class="form-input" />
        </div>
        <div class="form-group">
          <label>HARGA (Rp)</label>
          <input type="number" v-model.number="newMenu.harga" placeholder="Contoh: 35000" class="form-input" min="1" />
        </div>
        <div class="modal-actions">
          <button class="btn-sm btn-outline" @click="showMenuForm = false">Batal</button>
          <button class="btn-sm btn-approve" @click="submitNewMenu" :disabled="!newMenu.nama_item || !newMenu.harga || isSubmitting">
            {{ isSubmitting ? 'Menyimpan...' : 'Simpan' }}
          </button>
        </div>
      </div>
    </div>

    <!-- Toast Notifikasi -->
    <transition name="toast-slide">
      <div v-if="toast.show" :class="['toast-notification', toast.type === 'error' ? 'toast-error' : 'toast-success']">
        <svg v-if="toast.type === 'success'" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        <svg v-else width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        {{ toast.message }}
      </div>
    </transition>

    <button class="fab-btn" @click="handleFabClick">
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
    </button>

=======
>>>>>>> Stashed changes
    <nav class="staff-bottom-nav">
      <a href="#" class="nav-item" :class="{ active: activeTab === 'dashboard' }" @click.prevent="changeTab('dashboard')">
        <div class="icon-wrapper"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg></div>
        <span>Overview</span>
      </a>
      <a href="#" class="nav-item" :class="{ active: activeTab === 'reservations' }" @click.prevent="changeTab('reservations')">
        <div class="icon-wrapper"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div>
        <span>Reservasi</span>
      </a>
      <a href="#" class="nav-item" :class="{ active: activeTab === 'menu' }" @click.prevent="changeTab('menu')">
        <div class="icon-wrapper"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8h1a4 4 0 0 1 0 8h-1M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/></svg></div>
        <span>Menu</span>
      </a>
      <a href="#" class="nav-item" @click.prevent="exitToCustomer">
        <div class="icon-wrapper"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg></div>
        <span>Keluar</span>
      </a>
    </nav>
  </div>
</template>

<script setup lang="ts">
<<<<<<< Updated upstream
import { ref, computed, onMounted } from 'vue'
=======
import { ref, reactive } from 'vue'
>>>>>>> Stashed changes
import { globalStore } from './store'
import {
  getMeja, getMenus, getReservasi, updateReservasi, createMenu,
  occupyMeja, vacateMeja
} from './services/api'

const todayDate = new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
<<<<<<< Updated upstream

=======
>>>>>>> Stashed changes
const activeTab = ref('dashboard')
const uploadMessage = ref('')
const uploadSuccess = ref(false)

<<<<<<< Updated upstream
const exitToCustomer = () => {
=======
// Sample menu items
const menuItems = reactive([
  { 
    id: 1, 
    name: 'Iced Ceremonial Matcha', 
    price: 'IDR 45K',
    imagePreview: '',
    imageFile: null as File | null
  },
  { 
    id: 2, 
    name: 'Hojicha Latte', 
    price: 'IDR 40K',
    imagePreview: '',
    imageFile: null as File | null
  },
  { 
    id: 3, 
    name: 'Sencha Green Tea', 
    price: 'IDR 35K',
    imagePreview: '',
    imageFile: null as File | null
  }
])

const changeTab = (tab: string) => {
  activeTab.value = tab
}

const exitToCustomer = () => { 
>>>>>>> Stashed changes
  globalStore.isStaff = false
  globalStore.currentView = 'Home' 
}

<<<<<<< Updated upstream
// 1. DATA MEJA
const tables = ref<any[]>([])
const getTableClass = (status: string) => {
  if (status === 'occupied') return 'card-occ'
  if (status === 'cleaning') return 'card-cleaning'
  return ''
}
const syncTableToBackend = async (kode: string, newStatus: string) => {
  const meja = tables.value.find((t: any) => t.id === kode)
  if (!meja) return
  try {
    if (newStatus === 'occupied') {
      await occupyMeja(meja.id_meja)
    } else {
      await vacateMeja(meja.id_meja)
    }
    meja.status = newStatus
  } catch (e) {
    console.error('Gagal update meja', e)
  }
}

const refreshTables = async () => {
  try {
    const res = await getMeja()
    tables.value = res.data.map((m: any) => ({
      id: m.kode_meja,
      id_meja: m.id_meja,
      status: m.status_meja === 'terisi' ? 'occupied' : 'available',
    }))
  } catch (e) {
    console.error('Gagal refresh meja', e)
  }
}

// 2. DATA RESERVASI
const reservations = ref<any[]>([])
const pendingCount = computed(() => reservations.value.filter((r: any) => r.status === 'pending' || r.status === 'menunggu').length)

const statusMapToBackend: Record<string, string> = {
  pending: 'menunggu',
  approved: 'disetujui',
  arrived: 'hadir',
  rejected: 'ditolak',
}
const updateResStatus = async (id: number, newStatus: string) => {
  try {
    await updateReservasi(id, { status_reservasi: statusMapToBackend[newStatus] || newStatus })
    const res = reservations.value.find((r: any) => r.id === id)
    if (res) res.status = newStatus
  } catch (e) {
    console.error('Gagal update reservasi', e)
  }
}

// 3. DATA MENU
const menuItems = ref<any[]>([])

const syncPriceToBackend = (id: number, newPrice: number) => {
  console.log(`Backend Sync: Harga item ${id} jadi Rp${newPrice}`)
}

const syncAvailability = (id: number, isAvail: boolean) => {
  console.log(`Backend Sync: Status item ${id} ketersediaan: ${isAvail}`)
}

// 4. TAMBAH MENU
const showMenuForm = ref(false)
const isSubmitting = ref(false)
const newMenu = ref<{ nama_item: string; harga: number | null; deskripsi: string }>({
  nama_item: '',
  harga: null,
  deskripsi: '',
})

// Toast notifikasi
const toast = ref({ show: false, message: '', type: 'success' as 'success' | 'error' })
const showToast = (message: string, type: 'success' | 'error' = 'success') => {
  toast.value = { show: true, message, type }
  setTimeout(() => { toast.value.show = false }, 3000)
=======
// Image upload handler
const handleImageUpload = async (event: Event, menuId: number) => {
  uploadMessage.value = ''
  const input = event.target as HTMLInputElement
  const files = input.files
  
  if (!files || files.length === 0) return

  const file = files[0]
  
  // Type guard - ensure file exists
  if (!file) return
  
  const validFormats = ['image/png', 'image/jpeg', 'image/webp']
  
  // Validate file format
  if (!validFormats.includes(file.type)) {
    uploadMessage.value = 'Format file tidak valid. Gunakan PNG, JPG, JPEG, atau WebP.'
    uploadSuccess.value = false
    return
  }

  // Validate file size (max 5MB)
  if (file.size > 5 * 1024 * 1024) {
    uploadMessage.value = 'Ukuran file terlalu besar. Max 5MB.'
    uploadSuccess.value = false
    return
  }

  try {
    // Convert image to WebP
    const webpData = await convertToWebP(file)
    
    // Find the menu item and store the WebP data
    const menuItem = menuItems.find(m => m.id === menuId)
    if (menuItem) {
      menuItem.imagePreview = webpData
      menuItem.imageFile = file as File | null
      uploadMessage.value = `Gambar "${file.name}" berhasil dikonversi ke WebP dan siap dikirim.`
      uploadSuccess.value = true
      
      // Clear message after 3 seconds
      setTimeout(() => {
        uploadMessage.value = ''
      }, 3000)

      // TODO: Send to database when ready
      // await uploadImageToDatabase(menuId, webpData)
    }
  } catch (error) {
    uploadMessage.value = 'Gagal mengkonversi gambar. Silakan coba lagi.'
    uploadSuccess.value = false
    console.error('Image conversion error:', error)
  }

  // Reset file input
  input.value = ''
}

// Convert image to WebP format
const convertToWebP = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    
    reader.onload = (e) => {
      const img = new Image()
      
      img.onload = () => {
        const canvas = document.createElement('canvas')
        canvas.width = img.width
        canvas.height = img.height
        
        const ctx = canvas.getContext('2d')
        if (!ctx) {
          reject(new Error('Failed to get canvas context'))
          return
        }
        
        ctx.drawImage(img, 0, 0)
        
        // Convert to WebP with quality setting
        canvas.toBlob(
          (blob) => {
            if (!blob) {
              reject(new Error('Failed to create blob'))
              return
            }
            
            // Convert blob to data URL for preview and storage
            const reader2 = new FileReader()
            reader2.onload = (event) => {
              const result = event.target?.result
              if (typeof result === 'string') {
                resolve(result)
              } else {
                reject(new Error('Failed to convert blob to data URL'))
              }
            }
            reader2.onerror = () => {
              reject(new Error('Failed to read blob'))
            }
            reader2.readAsDataURL(blob)
          },
          'image/webp',
          0.8 // 80% quality
        )
      }
      
      img.onerror = () => {
        reject(new Error('Failed to load image'))
      }
      
      const result = e.target?.result
      if (typeof result === 'string') {
        img.src = result
      } else {
        reject(new Error('Failed to read file'))
      }
    }
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'))
    }
    
    reader.readAsDataURL(file)
  })
>>>>>>> Stashed changes
}

const refreshMenu = async () => {
  try {
    const res = await getMenus()
    menuItems.value = res.data.map((m: any) => ({
      id: m.id_menu,
      name: m.nama_item,
      price: m.harga,
      isAvailable: true,
    }))
  } catch (e) {
    console.error('Gagal refresh menu', e)
  }
}

const submitNewMenu = async () => {
  if (!newMenu.value.nama_item || !newMenu.value.harga) return
  isSubmitting.value = true
  try {
    await createMenu({
      nama_item: newMenu.value.nama_item,
      harga: Number(newMenu.value.harga),
      deskripsi: newMenu.value.deskripsi,
    })
    showMenuForm.value = false
    newMenu.value = { nama_item: '', harga: null, deskripsi: '' }
    await refreshMenu()
    showToast('Menu berhasil ditambahkan!')
  } catch (e: any) {
    const msg =
      e?.response?.data?.message ||
      e?.response?.data?.errors
        ? Object.values(e?.response?.data?.errors ?? {}).flat().join(', ')
        : 'Gagal menambahkan menu. Periksa koneksi dan coba lagi.'
    showToast(String(msg), 'error')
    console.error('Gagal tambah menu', e)
  } finally {
    isSubmitting.value = false
  }
}

// 5. FLOATING ACTION BUTTON
const handleFabClick = () => {
  if (activeTab.value === 'menu') showMenuForm.value = true
  if (activeTab.value === 'dashboard') alert('TODO: Buka Modal Tambah Meja Fisik Baru')
  if (activeTab.value === 'reservations') alert('TODO: Buka Modal Buat Reservasi Manual (Walk-in)')
}

onMounted(async () => {
  try {
    const [mejaRes, menuRes, reservasiRes] = await Promise.all([
      getMeja(), getMenus(), getReservasi()
    ])

    tables.value = mejaRes.data.map((m: any) => ({
      id: m.kode_meja,
      id_meja: m.id_meja,
      status: m.status_meja === 'terisi' ? 'occupied' : 'available',
    }))

    menuItems.value = menuRes.data.map((m: any) => ({
      id: m.id_menu,
      name: m.nama_item,
      price: m.harga,
      isAvailable: true,
    }))

    const statusMap: Record<string, string> = {
      menunggu: 'pending',
      disetujui: 'approved',
      dibayar: 'approved',
      hadir: 'arrived',
      ditolak: 'rejected',
    }
    reservations.value = reservasiRes.data.map((r: any) => ({
      id: r.id_reservasi,
      name: r.nama_pelanggan,
      time: r.jam,
      pax: r.meja?.kapasitas || '-',
      tables: r.meja ? [r.meja.kode_meja] : [],
      status: statusMap[r.status_reservasi] || r.status_reservasi,
    }))
  } catch (e) {
    console.error('Gagal memuat data dashboard', e)
  }
})
</script>

<style scoped>
:root { --bg-main: #F4F7F0; --text-main: #2A3620; --card-bg: #EAEFE4; --primary: #4A5837; --font-serif: 'Georgia', serif; }
* { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, sans-serif; }
.mobile-container { max-width: 414px; margin: 0 auto; background-color: #F4F7F0; color: #2A3620; min-height: 100vh; position: relative; }
.scroll-content { padding-bottom: 110px; height: 100vh; overflow-y: auto; scrollbar-width: none; }
.scroll-content::-webkit-scrollbar { display: none; }

/* TAB TRANSITION CLASSES */
.tab-fade-enter-active, .tab-fade-leave-active { transition: opacity 0.2s ease, transform 0.2s ease; }
.tab-fade-enter-from { opacity: 0; transform: translateX(10px); }
.tab-fade-leave-to { opacity: 0; transform: translateX(-10px); }

/* Standard Dashboard CSS */
.top-nav { display: flex; justify-content: space-between; padding: 20px 24px; align-items: center; }
.icon-btn { background: none; border: none; color: #5B6A4B; cursor: pointer; transition: transform 0.2s; }
.icon-btn:active { transform: scale(0.95); }
.logo-text { font-family: 'Georgia', serif; font-size: 1.5rem; font-weight: bold; }
.content { padding: 0 24px; }
.title { font-family: 'Georgia', serif; font-size: 1.8rem; font-weight: normal; margin-bottom: 8px; }
.date-display { font-size: 0.9rem; color: #4A5837; margin-bottom: 24px; }
.stats-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 32px; }
.stat-card { background-color: #EAEFE4; padding: 16px; border-radius: 12px; }
.stat-top { margin-bottom: 4px; color: #2A3620; }
.stat-number { font-family: 'Georgia', serif; font-size: 1.8rem; font-weight: bold;}
.stat-label { font-size: 0.65rem; font-weight: 600; color: #5B6A4B; letter-spacing: 0.5px; }

/* Reservation Styles */
.section-header { margin-bottom: 16px; }
.section-header h2 { font-family: 'Georgia', serif; font-size: 1.3rem; font-weight: normal; }
.table-status-scroll { display: flex; gap: 12px; overflow-x: auto; padding-bottom: 10px; }
.table-card { background: white; border-radius: 12px; padding: 16px; min-width: 140px; text-align: center; }
.table-name { font-weight: 600; margin-bottom: 8px; }
.status-dropdown { font-size: 0.75rem; background: #EEF2EA; padding: 4px 8px; border-radius: 8px; display: inline-block; }
.card-occ { border: 1px solid #FFE0E0; background: #FFF5F5; }

.reservation-list { display: flex; flex-direction: column; gap: 12px; }
.res-card { background: white; border-radius: 12px; padding: 16px; border: 1px solid rgba(74, 88, 55, 0.08); }
.res-info h3 { font-size: 1rem; font-weight: 600; }
.res-info p { font-size: 0.85rem; color: #5B6A4B; margin-top: 8px; }
.badge { font-size: 0.65rem; font-weight: 600; padding: 4px 10px; border-radius: 12px; }
.badge-pending { background: #FFF9E6; color: #D4A500; }

/* MENU MANAGEMENT STYLES */
.menu-admin-list { display: flex; flex-direction: column; gap: 16px; margin-bottom: 40px; }

.menu-admin-card { 
  background: white; 
  border-radius: 16px; 
  padding: 16px; 
  border: 1px solid rgba(74, 88, 55, 0.08);
  transition: all 0.3s ease;
}

<<<<<<< Updated upstream
/* Modal */
.modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; justify-content: center; align-items: center; z-index: 10000; }
.modal-overlay .modal-content { background: white; padding: 24px; border-radius: 16px; width: 85%; max-width: 340px; }
.modal-overlay .modal-content h3 { font-family: var(--font-serif); margin-bottom: 20px; }
.modal-overlay .form-group { margin-bottom: 16px; }
.modal-overlay .form-group label { display: block; font-size: 0.7rem; font-weight: 600; color: #5B6A4B; margin-bottom: 6px; letter-spacing: 0.5px; }
.modal-overlay .form-input { width: 100%; padding: 12px; border: 1px solid #D6DED0; border-radius: 10px; font-size: 0.9rem; outline: none; }
.modal-overlay .modal-actions { display: flex; gap: 12px; margin-top: 24px; }
.modal-overlay .modal-actions .btn-sm { flex: 1; }
.modal-overlay .btn-sm:disabled { opacity: 0.5; cursor: not-allowed; }

/* FAB */
.fab-btn { position: fixed; bottom: 84px; left: 50%; transform: translateX(130px); width: 52px; height: 52px; background-color: #4A5837; border-radius: 50%; border: none; display: flex; justify-content: center; align-items: center; box-shadow: 0 4px 12px rgba(74, 88, 55, 0.3); cursor: pointer; z-index: 999; }
.fab-btn:active { transform: translateX(130px) scale(0.95); }

/* Bottom Nav */
.staff-bottom-nav { position: fixed; bottom: 0; left: 50%; transform: translateX(-50%); width: 100%; max-width: 414px; background: white; display: flex; justify-content: space-around; padding: 12px 0; border-top-left-radius: 24px; border-top-right-radius: 24px; box-shadow: 0 -4px 20px rgba(0,0,0,0.05); z-index: 9999; }
.staff-bottom-nav .nav-item { display: flex; flex-direction: column; align-items: center; text-decoration: none; color: #A0A0A0; gap: 4px; flex: 1; }
.staff-bottom-nav .nav-item span { font-size: 0.65rem; font-weight: 500; }
.icon-wrapper { padding: 6px 16px; border-radius: 16px; display: flex; justify-content: center; align-items: center; transition: 0.2s;}
.staff-bottom-nav .nav-item.active { color: #4A5837; }
.staff-bottom-nav .nav-item.active .icon-wrapper { background: #EEF2EA; }
/* Toast Notifikasi */
.toast-notification {
  position: fixed;
  top: 24px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 20px;
  border-radius: 12px;
  font-size: 0.85rem;
  font-weight: 600;
  z-index: 99999;
  box-shadow: 0 4px 20px rgba(0,0,0,0.15);
  max-width: 320px;
  text-align: center;
  white-space: nowrap;
}
.toast-success { background: #4A5837; color: white; }
.toast-error   { background: #C62828; color: white; }

.toast-slide-enter-active, .toast-slide-leave-active { transition: all 0.3s ease; }
.toast-slide-enter-from, .toast-slide-leave-to { opacity: 0; transform: translateX(-50%) translateY(-12px); }
=======
.menu-admin-card:hover {
  box-shadow: 0 4px 16px rgba(74, 88, 55, 0.1);
}

.menu-admin-image-section {
  margin-bottom: 16px;
  position: relative;
}

.menu-image-preview {
  width: 100%;
  height: 180px;
  border-radius: 12px;
  overflow: hidden;
  background: #F5F5F5;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 12px;
}

.menu-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.menu-image-placeholder {
  width: 100%;
  height: 180px;
  border-radius: 12px;
  background: #EAEFE4;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 12px;
  color: #A4B298;
}

.upload-label {
  display: block;
  cursor: pointer;
}

.file-input {
  display: none;
}

.upload-btn {
  display: block;
  width: 100%;
  padding: 12px 16px;
  background: linear-gradient(135deg, #4A5837 0%, #5B6A4B 100%);
  color: white;
  border-radius: 10px;
  font-weight: 600;
  font-size: 0.9rem;
  text-align: center;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(74, 88, 55, 0.2);
}

.upload-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(74, 88, 55, 0.3);
}

.upload-btn:active {
  transform: translateY(0);
  box-shadow: 0 2px 8px rgba(74, 88, 55, 0.2);
}

.menu-admin-info {
  text-align: center;
}

.menu-admin-info h4 {
  font-family: 'Georgia', serif;
  font-size: 1.05rem;
  margin-bottom: 6px;
  color: var(--text-main);
  font-weight: normal;
}

.price-display {
  font-size: 0.95rem;
  font-weight: 600;
  color: var(--primary);
}

.upload-status {
  padding: 16px;
  margin: 16px 0;
  border-radius: 12px;
  text-align: center;
  animation: slideUp 0.3s ease;
}

.success-msg {
  background: #E8F5E9;
  color: #2E7D32;
  padding: 12px;
  border-radius: 8px;
  font-size: 0.9rem;
  font-weight: 500;
}

.error-msg {
  background: #FFEBEE;
  color: #C62828;
  padding: 12px;
  border-radius: 8px;
  font-size: 0.9rem;
  font-weight: 500;
}

@keyframes slideUp {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* Staff Navbar Animations */
.staff-bottom-nav { 
  position: fixed; 
  bottom: 0; 
  left: 50%; 
  transform: translateX(-50%); 
  width: 100%; 
  max-width: 414px; 
  background: white; 
  display: flex; 
  justify-content: space-around; 
  padding: 12px 0; 
  border-top-left-radius: 24px; 
  border-top-right-radius: 24px; 
  box-shadow: 0 -4px 20px rgba(0,0,0,0.05); 
  z-index: 9999;
}

.staff-bottom-nav .nav-item { 
  display: flex; 
  flex-direction: column; 
  align-items: center; 
  text-decoration: none; 
  color: #A0A0A0; 
  gap: 4px; 
  flex: 1; 
  transition: color 0.3s ease; 
}

.staff-bottom-nav .nav-item span { 
  font-size: 0.65rem; 
  font-weight: 500; 
}

.icon-wrapper { 
  padding: 6px 16px; 
  border-radius: 16px; 
  display: flex; 
  justify-content: center; 
  align-items: center; 
  transition: background-color 0.3s ease, transform 0.2s;
}

.staff-bottom-nav .nav-item:active .icon-wrapper { 
  transform: scale(0.9); 
}

.staff-bottom-nav .nav-item.active { 
  color: #4A5837; 
}

.staff-bottom-nav .nav-item.active .icon-wrapper { 
  background: #EEF2EA; 
}
>>>>>>> Stashed changes
</style>